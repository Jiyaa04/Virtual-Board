from flask import Flask, render_template, redirect, url_for, request
import subprocess

app = Flask(__name__)

process = None  # To track the subprocess running main.py

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start')
def start_main():
    global process
    process = subprocess.Popen(["python", "main.py"])
    return render_template('canvas.html')

@app.route('/exit')
def exit_main():
    global process
    if process:
        process.terminate()
        process = None
    return redirect(url_for('index'))

@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    if request.method == 'POST':
        # Handle feedback submission
        name = request.form['name']
        feedback = request.form['feedback']
        print(f"Feedback received from {name}: {feedback}")
        return render_template('thank_you.html', name=name)
    return render_template('feedback.html')

if __name__ == "__main__":
    app.run(debug=True)
