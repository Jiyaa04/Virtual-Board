import cv2
import numpy as np
import mediapipe as mp
from collections import deque

# Initialize Mediapipe Hands
mpHands = mp.solutions.hands
hands = mpHands.Hands(max_num_hands=1, min_detection_confidence=0.7)
mpDraw = mp.solutions.drawing_utils

# Color palette for drawing
colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (0, 255, 255)]  # Blue, Green, Red, Yellow
colorIndex = 0  # Default color index

# Points deque for different colors
bpoints = [deque(maxlen=1024)]
gpoints = [deque(maxlen=1024)]
rpoints = [deque(maxlen=1024)]
ypoints = [deque(maxlen=1024)]

blue_index = 0
green_index = 0
red_index = 0
yellow_index = 0

# Create paint window
paintWindow = np.ones((471, 636, 3), dtype=np.uint8) * 255
paintWindow = cv2.rectangle(paintWindow, (40, 1), (140, 65), (0, 0, 0), 2)
paintWindow = cv2.rectangle(paintWindow, (160, 1), (255, 65), (255, 0, 0), 2)
paintWindow = cv2.rectangle(paintWindow, (275, 1), (370, 65), (0, 255, 0), 2)
paintWindow = cv2.rectangle(paintWindow, (390, 1), (485, 65), (0, 0, 255), 2)
paintWindow = cv2.rectangle(paintWindow, (505, 1), (600, 65), (0, 255, 255), 2)

cv2.putText(paintWindow, "CLEAR", (49, 33), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2, cv2.LINE_AA)
cv2.putText(paintWindow, "BLUE", (185, 33), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2, cv2.LINE_AA)
cv2.putText(paintWindow, "GREEN", (298, 33), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2, cv2.LINE_AA)
cv2.putText(paintWindow, "RED", (420, 33), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2, cv2.LINE_AA)
cv2.putText(paintWindow, "YELLOW", (520, 33), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2, cv2.LINE_AA)

cv2.namedWindow('Paint', cv2.WINDOW_AUTOSIZE)

def process_frame(frame):
    global bpoints, gpoints, rpoints, ypoints, blue_index, green_index, red_index, yellow_index, colorIndex

    frame = cv2.flip(frame, 1)
    framergb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Draw buttons on the frame
    buttons = [((40, 1), (140, 65)), ((160, 1), (255, 65)), ((275, 1), (370, 65)),
               ((390, 1), (485, 65)), ((505, 1), (600, 65))]
    for i, button in enumerate(buttons):
        color = (0, 0, 0) if i == 0 else colors[i - 1]
        frame = cv2.rectangle(frame, button[0], button[1], color, 2)
        labels = ["CLEAR", "BLUE", "GREEN", "RED", "YELLOW"]
        cv2.putText(frame, labels[i], (button[0][0] + 20, button[0][1] + 33),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2, cv2.LINE_AA)

    # Detect hand landmarks
    result = hands.process(framergb)
    if result.multi_hand_landmarks:
        for handslms in result.multi_hand_landmarks:
            landmarks = [(int(lm.x * frame.shape[1]), int(lm.y * frame.shape[0])) for lm in handslms.landmark]
            fore_finger = landmarks[8]  # Index finger tip
            thumb = landmarks[4]        # Thumb tip
            cv2.circle(frame, fore_finger, 5, (0, 255, 0), -1)

            # Check for click gestures
            if thumb[1] - fore_finger[1] < 30:
                bpoints.append(deque(maxlen=1024))
                gpoints.append(deque(maxlen=1024))
                rpoints.append(deque(maxlen=1024))
                ypoints.append(deque(maxlen=1024))
            elif fore_finger[1] <= 65:  # Top button clicks
                if 40 <= fore_finger[0] <= 140:  # Clear button
                    bpoints, gpoints, rpoints, ypoints = [[deque(maxlen=1024)] for _ in range(4)]
                    blue_index = green_index = red_index = yellow_index = 0
                    paintWindow[67:, :, :] = 255
                elif 160 <= fore_finger[0] <= 255:
                    colorIndex = 0  # Blue
                elif 275 <= fore_finger[0] <= 370:
                    colorIndex = 1  # Green
                elif 390 <= fore_finger[0] <= 485:
                    colorIndex = 2  # Red
                elif 505 <= fore_finger[0] <= 600:
                    colorIndex = 3  # Yellow
            else:
                if colorIndex == 0:
                    bpoints[blue_index].appendleft(fore_finger)
                elif colorIndex == 1:
                    gpoints[green_index].appendleft(fore_finger)
                elif colorIndex == 2:
                    rpoints[red_index].appendleft(fore_finger)
                elif colorIndex == 3:
                    ypoints[yellow_index].appendleft(fore_finger)

    # Draw lines on frame and paintWindow
    points = [bpoints, gpoints, rpoints, ypoints]
    for i, color_points in enumerate(points):
        for point_deque in color_points:
            for k in range(1, len(point_deque)):
                if point_deque[k - 1] and point_deque[k]:
                    cv2.line(frame, point_deque[k - 1], point_deque[k], colors[i], 2)
                    cv2.line(paintWindow, point_deque[k - 1], point_deque[k], colors[i], 2)

    return frame

# Start Video Capture
cap = cv2.VideoCapture(0)
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break
    processed_frame = process_frame(frame)
    cv2.imshow("Output", processed_frame)
    cv2.imshow("Paint", paintWindow)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
